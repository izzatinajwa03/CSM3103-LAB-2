
document.addEventListener('volumedownbutton', onVolumeKeyDown, false);

function onVolumeKeyDown() {
    alert("You press volume down!")
   
}
document.addEventListener('backbutton',onBackButton,false);

function onBackButton(e) {
    e.preventDefault();
    alert("back button pressed!");
}
